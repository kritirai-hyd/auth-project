// app/manager/dashboard/page.jsx

import ManagerPage from "@/components/ManagerInfoForm";


export default async function ManagerDashboard() {


  return (
    <main>

      <ManagerPage />
    </main>
  );
}
