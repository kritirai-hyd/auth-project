// app/dashboard/page.jsx or pages/dashboard.jsx depending on your setup
"use client";

import LoginForm from "@/components/LoginForm";


export default function DashboardPage() {
 
  return <>
  <LoginForm />
  </>;
}
